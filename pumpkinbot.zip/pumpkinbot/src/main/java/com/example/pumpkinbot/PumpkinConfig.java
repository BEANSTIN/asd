package com.example.pumpkinbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class PumpkinConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("pumpkinbot.json");
    private static PumpkinConfig instance;

    public boolean enabled = false;
    public boolean shearPumpkins = true;
    public boolean breakCarved = true;
    public int radius = 4;   // 1-6 blocks scanned around the player
    public int delay = 4;    // ticks between actions (1-20)

    public static PumpkinConfig get() {
        if (instance == null) instance = load();
        return instance;
    }

    private static PumpkinConfig load() {
        try {
            if (Files.exists(PATH)) {
                PumpkinConfig c = GSON.fromJson(Files.readString(PATH), PumpkinConfig.class);
                if (c != null) {
                    c.radius = Math.max(1, Math.min(6, c.radius));
                    c.delay = Math.max(1, Math.min(20, c.delay));
                    return c;
                }
            }
        } catch (Exception e) {
            System.err.println("[PumpkinBot] Failed to read config: " + e);
        }
        return new PumpkinConfig();
    }

    public void save() {
        try {
            Files.writeString(PATH, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[PumpkinBot] Failed to save config: " + e);
        }
    }
}
