package com.example.pumpkinbot;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Client-side: works in singleplayer and on servers.
 * 1) Breaks nearby carved pumpkins with an axe from your hotbar.
 * 2) Otherwise carves nearby pumpkins with shears from your hotbar.
 */
public class PumpkinBotClient implements ClientModInitializer {
    private static final double REACH = 4.5;

    private static KeyMapping toggleKey;
    private static int cooldown = 0;
    private static int previousSlot = -1;
    private static BlockPos mining = null;

    @Override
    public void onInitializeClient() {
        PumpkinConfig.get();

        KeyMapping.Category category = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("pumpkinbot", "main"));

        toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
            "key.pumpkinbot.toggle", InputConstants.Type.KEYSYM, InputConstants.KEY_P, category));

        ClientTickEvents.END_CLIENT_TICK.register(PumpkinBotClient::tick);
    }

    private static void tick(Minecraft mc) {
        PumpkinConfig cfg = PumpkinConfig.get();
        LocalPlayer player = mc.player;

        while (toggleKey.consumeClick()) {
            cfg.enabled = !cfg.enabled;
            cfg.save();
            if (player != null) {
                player.displayClientMessage(
                    Component.literal("Pumpkin Bot: " + (cfg.enabled ? "ON" : "OFF")), true);
            }
        }

        MultiPlayerGameMode gm = mc.gameMode;
        if (player == null || gm == null || mc.level == null) return;

        if (!cfg.enabled || mc.gui.screen() != null || player.isSpectator()) {
            stopMining(gm);
            return;
        }

        // Keep mining the current carved pumpkin until it's gone.
        if (mining != null) {
            boolean stillThere = mc.level.getBlockState(mining).is(Blocks.CARVED_PUMPKIN);
            boolean inReach = Vec3.atCenterOf(mining).distanceToSqr(player.getEyePosition()) <= REACH * REACH;
            int axe = findHotbar(player, true);
            if (stillThere && inReach && axe >= 0) {
                player.getInventory().setSelectedSlot(axe);
                gm.continueDestroyBlock(mining, Direction.UP);
                player.swing(InteractionHand.MAIN_HAND);
                return;
            }
            stopMining(gm);
        }

        if (cooldown > 0) {
            cooldown--;
            return;
        }
        cooldown = cfg.delay;

        BlockPos origin = player.blockPosition();
        Vec3 eyes = player.getEyePosition();
        BlockPos carved = null, pumpkin = null;
        double bestCarved = Double.MAX_VALUE, bestPumpkin = Double.MAX_VALUE;
        int r = cfg.radius;

        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-r, -r, -r), origin.offset(r, r, r))) {
            Block block = mc.level.getBlockState(p).getBlock();
            boolean isCarved = block == Blocks.CARVED_PUMPKIN;
            boolean isPumpkin = block == Blocks.PUMPKIN;
            if (!isCarved && !isPumpkin) continue;

            double d = Vec3.atCenterOf(p).distanceToSqr(eyes);
            if (d > REACH * REACH) continue;

            if (isCarved && d < bestCarved) { bestCarved = d; carved = p.immutable(); }
            if (isPumpkin && d < bestPumpkin) { bestPumpkin = d; pumpkin = p.immutable(); }
        }

        if (cfg.breakCarved && carved != null) {
            int axe = findHotbar(player, true);
            if (axe >= 0) {
                selectSlot(player, axe);
                mining = carved;
                gm.startDestroyBlock(mining, Direction.UP);
                player.swing(InteractionHand.MAIN_HAND);
                return;
            }
        }

        if (cfg.shearPumpkins && pumpkin != null && !player.isShiftKeyDown()) {
            int shears = findHotbar(player, false);
            if (shears >= 0) {
                selectSlot(player, shears);
                BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(pumpkin), Direction.UP, pumpkin, false);
                gm.useItemOn(player, InteractionHand.MAIN_HAND, hit);
                player.swing(InteractionHand.MAIN_HAND);
                return;
            }
        }

        // Nothing to do: go back to whatever the player was holding.
        if (previousSlot >= 0) {
            player.getInventory().setSelectedSlot(previousSlot);
            previousSlot = -1;
        }
    }

    private static void selectSlot(LocalPlayer player, int slot) {
        if (previousSlot < 0) previousSlot = player.getInventory().getSelectedSlot();
        player.getInventory().setSelectedSlot(slot);
    }

    private static void stopMining(MultiPlayerGameMode gm) {
        if (mining != null) {
            gm.stopDestroyBlock();
            mining = null;
        }
    }

    /** Finds an axe (axe=true) or shears (axe=false) in the hotbar. */
    private static int findHotbar(LocalPlayer player, boolean axe) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.isEmpty()) continue;
            if (axe ? s.is(ItemTags.AXES) : s.is(Items.SHEARS)) return i;
        }
        return -1;
    }
}
