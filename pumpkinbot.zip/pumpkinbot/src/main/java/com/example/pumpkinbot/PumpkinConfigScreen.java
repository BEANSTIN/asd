package com.example.pumpkinbot;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;

public class PumpkinConfigScreen extends Screen {
    private final Screen parent;
    private final PumpkinConfig cfg = PumpkinConfig.get();

    public PumpkinConfigScreen(Screen parent) {
        super(Component.literal("Pumpkin Bot"));
        this.parent = parent;
    }

    private static Component onOff(String label, boolean value) {
        return Component.literal(label + ": " + (value ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int w = 220;
        int x = this.width / 2 - w / 2;
        int y = this.height / 4 - 4;
        int step = 24;

        this.addRenderableWidget(Button.builder(onOff("Enabled", cfg.enabled), b -> {
            cfg.enabled = !cfg.enabled;
            b.setMessage(onOff("Enabled", cfg.enabled));
        }).bounds(x, y, w, 20).build());

        this.addRenderableWidget(Button.builder(onOff("Carve pumpkins (shears)", cfg.shearPumpkins), b -> {
            cfg.shearPumpkins = !cfg.shearPumpkins;
            b.setMessage(onOff("Carve pumpkins (shears)", cfg.shearPumpkins));
        }).bounds(x, y + step, w, 20).build());

        this.addRenderableWidget(Button.builder(onOff("Break carved (axe)", cfg.breakCarved), b -> {
            cfg.breakCarved = !cfg.breakCarved;
            b.setMessage(onOff("Break carved (axe)", cfg.breakCarved));
        }).bounds(x, y + step * 2, w, 20).build());

        this.addRenderableWidget(new IntSlider(x, y + step * 3, w, 20, "Scan radius", 1, 6, cfg.radius,
            v -> cfg.radius = v));

        this.addRenderableWidget(new IntSlider(x, y + step * 4, w, 20, "Delay (ticks)", 1, 20, cfg.delay,
            v -> cfg.delay = v));

        this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> this.onClose())
            .bounds(x, this.height - 32, w, 20).build());
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        drawCentered(graphics, "Pumpkin Bot", 20, 0xFFFFFFFF);
        drawCentered(graphics, "Keep shears and an axe in your hotbar", 34, 0xFFAAAAAA);
    }

    private void drawCentered(GuiGraphicsExtractor graphics, String text, int y, int color) {
        graphics.text(this.font, text, this.width / 2 - this.font.width(text) / 2, y, color, true);
    }

    @Override
    public void onClose() {
        cfg.save();
        this.minecraft.gui.setScreen(this.parent);
    }

    private static class IntSlider extends AbstractSliderButton {
        private final String label;
        private final int min, max;
        private final IntConsumer onChange;

        IntSlider(int x, int y, int w, int h, String label, int min, int max, int current, IntConsumer onChange) {
            super(x, y, w, h, Component.empty(), (current - min) / (double) (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.onChange = onChange;
            this.updateMessage();
        }

        private int current() {
            return min + (int) Math.round(this.value * (max - min));
        }

        @Override
        protected void updateMessage() {
            this.setMessage(Component.literal(label + ": " + current()));
        }

        @Override
        protected void applyValue() {
            onChange.accept(current());
        }
    }
}
