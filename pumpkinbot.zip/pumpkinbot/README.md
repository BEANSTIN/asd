# Pumpkin Bot (Fabric, Minecraft 26.3)

Client-side mod (works in singleplayer and on servers). Requires Fabric API.
Mod Menu is optional but gives you a settings screen.

## Use
1. Put **shears** and an **axe** in your hotbar.
2. Stand near pumpkins and press **P** (rebindable under Controls > Key Binds > Pumpkin Bot),
   or enable it from the Mod Menu config screen.
3. It carves pumpkins in reach with shears, then breaks the carved pumpkins with the axe.

## Settings (Mod Menu > Pumpkin Bot > Configure)
Enabled, Carve pumpkins, Break carved, Scan radius (1-6), Delay in ticks (1-20).
Saved to `config/pumpkinbot.json`.

## Requirements
Minecraft 26.3, Fabric Loader 0.19.3+, Fabric API 0.163.0+26.3 (or newer 26.3 build), Java 25.
Optional: Mod Menu 21.x for 26.3.

## Build the .jar
Needs JDK 25 and Gradle 9.5.1. Run `gradle build`; the jar is in `build/libs/`
(use the one WITHOUT `-sources`).

No local setup? Upload this whole folder (including the hidden `.github` folder) to a GitHub repo,
open **Actions > build > Run workflow**, then download the **pumpkinbot-jar** artifact.

## Notes
- Sneaking prevents shearing, so stay unsneaked.
- Carved pumpkins you placed on purpose (golem builds) within reach will also be broken.
- Automation may be against the rules on multiplayer servers; check first.
- Written against the 26.2/26.3 APIs (Mojang names, `extractRenderState`, `gui.setScreen`).
  Snapshots of 26.4 change the `extractRenderState` signature.
